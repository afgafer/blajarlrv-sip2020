<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Dest extends Model
{
    // public function hotel(){
    //     return $this->belongsToMany('App\models\Hotel','admins','dest_id','hotel_id');
    // }
}
