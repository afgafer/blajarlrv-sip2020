<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('message')): ?>
 <div class="alert alert-success martop-sm">
 <p><?php echo e($message); ?></p>
 </div>
<?php endif; ?>
<h1 class="title">dests</h1>
<hr>
<div class="card-columns">
            <?php $__empty_1 = true; $__currentLoopData = $dests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $dirF='upload/img/'.$d->file;
            $src=asset($dirF);
            ?>
            <div class="card p-0 bg-transparent">
                <a class="text-white" href="<?php echo e(route('dest.showA',$d->id)); ?>">
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($d->file); ?>">
                <div class="card-body text-center bg-secondary">
                    <h5 ><?php echo e($d->name); ?></h5>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card p-0">
                <div class="card-body">
                    <h5>empty</h5>
                </div>
            </div>
            <?php endif; ?>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/dest/index.blade.php ENDPATH**/ ?>