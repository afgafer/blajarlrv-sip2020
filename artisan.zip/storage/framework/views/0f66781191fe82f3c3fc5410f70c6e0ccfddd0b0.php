<?php $__env->startSection('content'); ?>
<?php if(isset($cart)): ?>
<div class="bg-limpid-light p-2">
    <div class="bg-light">
        <h1 class="title">form</h1>
        <div class="form-row p-2">
            <div class="form-group col-md-6">
                <label for="name">name</label>
                <input type="text" value="<?php echo e(Session::get('name')); ?>" class="form-control" readonly>
            </div>
            <div class="form-group col-md-2">
                <label for="hotel">hotel</label>
                <input type="text" value="<?php echo e(Session::get('hotel')); ?>" class="form-control" readonly>
            </div>
            <div class="form-group col-md-2">
                <label for="cin">cin : 08.00</label>
                <input type="date"  value="<?php echo e(Session::get('cin')); ?>" class="form-control" readonly>
            </div>
            <div class="form-group col-md-2">
                <label for="cout">cout : 06.00</label>
                <input type="date" value="<?php echo e(Session::get('cout')); ?>" class="form-control" readonly>
            </div>
        </div>
    </div>
    <?php if($msg = Session::get('msg')): ?>
    <div class="alert alert-info" role="alert">
        <?php echo e($msg); ?>

    </div>
    <?php endif; ?>
    <div class="scroll mt-2">
        <table class="table-sm table-striped w-100 bg-limpid-light">
            <tr class="bg-primary text-white">
                <th>No</th>
                <th>room</th>
                <th>price</th>
                <th>quantity</th>
                <th></th>
            </tr>

            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($c['item']->id); ?></td>
                <td><?php echo e($c['item']->name); ?></td>
                <td><?php echo e($c['cost']); ?></td>
                <td>
                    <div class="row" style="width:200px">
                        <div class="d-inline">
                            <form action="<?php echo e(route('cart.take',$c['item']->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-secondary btn-sm">+</button>
                            </form>
                        </div>
                        <div class="d-inline" style="width:50px">
                            <input type="number" value="<?php echo e($c['qty']); ?>" max="<?php echo e($c['item']->quota); ?>" class="form-control p-0"
                                readonly>    
                        </div>
                        <div class="d-inline">
                            <form action="<?php echo e(route('cart.remove',$c['item']->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-secondary btn-sm">-</button>
                            </form>    
                        </div>
                    </div>
                </td>
                <td>
                    <form action="<?php echo e(route('cart.destroy',$c['item']->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('POst')); ?>

                        <button class="btn btn-danger" type='submit'>delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th colspan="2" class=>Tarif</th>
                <th><?php echo e($bill); ?></th>
                <th><?php echo e($count); ?></th>
                <th></th>
            </tr>
        </table>
        <?php else: ?>
        tidak ada
        <?php endif; ?>
    </div>
    <?php if($count!=0): ?>
    <form action="<?php echo e(route('order.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="hidden" name="name" value="<?php echo e(Session::get('name')); ?>" class="form-control col-md-8">
        </div>
        <div class="form-row">
            <div class="form-group col-md-6">
                <input type="hidden" name="cin" value="<?php echo e(Session::get('cin')); ?>" class="form-control" readonly>
            </div>
            <div class="form-group col-md-6">
                <input type="hidden" name="cout" value="<?php echo e(Session::get('cout')); ?>" class="form-control col-md-6"
                    readonly>
            </div>
            <button class="btn btn-success" type="submit">order</button>
    </form>
    <?php endif; ?>
    <form action="<?php echo e(route('order.choice',session()->get('hotel_id'))); ?>" method="get">
        <?php echo e(csrf_field()); ?>

        <button class="btn btn-primary" type='submit'>choice</button>
    </form>
    <form action="<?php echo e(route('cart.drop')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('POST')); ?>

        <button class="btn btn-warning" type='submit'>cancel</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/cart/index.blade.php ENDPATH**/ ?>