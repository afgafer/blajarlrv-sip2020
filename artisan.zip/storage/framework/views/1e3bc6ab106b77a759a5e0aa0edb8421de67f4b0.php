<?php $__env->startSection('content'); ?>
<h1 class="text-center title">dests</h1>
<div class="card-columns">
            <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $dirF='upload/img/'.$i->file;
            $src=asset($dirF);
            ?>
            <div class="box">
                <a class="text-white" href="<?php echo e(route('image.show',$i->id)); ?>">
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($i->file); ?>">
                <div class="overlay">
                    <h5 ><?php echo e($i->name); ?></h5>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card p-0">
                <div class="card-body">
                    <h5>empty</h5>
                </div>
            </div>
            <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/image/index.blade.php ENDPATH**/ ?>