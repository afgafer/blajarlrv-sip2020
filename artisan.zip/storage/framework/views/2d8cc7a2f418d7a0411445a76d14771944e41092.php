<?php $__env->startSection('content'); ?>
        <a class="btn btn-primary" href="<?php echo e(route('image.create')); ?>">create</a>
        <table class="table table-striped table-light table-sm">
            <thead>
                <tr class='bg-primary text-white'>
                    <th>No</th>
                    <th>name</th>
                    <th>status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                $dirF='upload/img/'.$i->file;
                $src=asset($dirF);
                ?>
                <tr class=''>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><img src="<?php echo e($src); ?>" width='100px' clas="img-thumb" alt="<?php echo e($i->file); ?>"> <?php echo e($i->name); ?></td>
                    <td>
                    <form action="<?php echo e(route('image.pConfirm',$i->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('put')); ?>

                        <select name="status" class="form-control" onchange="this.form.submit()">
                            <option disabled selected>--Confirm--</option>
                            <option value="1">accept</option>
                            <option value="2">abort</option>
                        </select>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <td colspan="4" class="text-center">empty</td>
                <?php endif; ?>
            </tbody>
        </table>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/image/index.blade.php ENDPATH**/ ?>