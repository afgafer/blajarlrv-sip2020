<?php $__env->startSection('content'); ?>
<?php if(Session::get('message')): ?>
<?php
$message = Session::get('message');
?>
 <div class="alert alert-success martop-sm">
 <p><?php echo e($message); ?></p>
 </div>
<?php endif; ?>
<h1 class="bg-secondary text-white text-center">rooms</h1>
<div class="card-columns">
            <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            if(Session::has('cart')){
                $cart=Session::get('cart');
                if (array_key_exists($r->id,$cart->items)){
                    continue;
                }
            }
            $dirF='upload/img/'.$r->file;
            $src=asset($dirF);
            $price=number_format($r->price,0,',','.')
            ?>
            <div class="card p-0">
                <a class="text-dark" href="<?php echo e(route('room.showA',$r->id)); ?>">
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($r->file); ?>">
                <div class="card-body">
                    <h5 class="card-title text-white badge badge-primary">No <?php echo e($r->id); ?></h5>
                    <h5 class="card-title border badge badge-light">Rp <?php echo e($r->price); ?></h5>
                    <table class="table table-sm bg-white mb-2 ">
                        <tbody>
                            <tr>
                                <td >Name</td>
                                <td>: <?php echo e($r->name); ?></td>
                            </tr>
                            <tr>
                                <td>hotel</td>
                                <td>: <?php echo e($r->hotel->name); ?></td>
                            </tr>
                            <tr>
                                <td>bed</td>
                                <td>: <?php echo e($r->bed); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card p-0">
                <div class="card-body">
                    <h5>empty</h5>
                </div>
            </div>
            <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/room/index.blade.php ENDPATH**/ ?>