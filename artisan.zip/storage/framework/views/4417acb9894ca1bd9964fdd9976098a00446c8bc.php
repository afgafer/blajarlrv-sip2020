<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('message')): ?>
 <div class="alert alert-success martop-sm">
 <p><?php echo e($message); ?></p>
 </div>
<?php endif; ?>
<h1 class="title">events</h1>
<a href="<?php echo e(route('event.create')); ?>" class="btn btn-primary btn-sm">create</a>
<div class="scroll">
    <table class="table table-sm bg-white mb-2 ">
        <tbody>
            <tr class="bg-primary text-white">
                <th>no</th>
                <th>name</th>
                <th>date</th>
                <th>place</th>
                <th></th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $dirF='upload/img/'.$e->file;
            $src=asset($dirF);
            $time=date_create($e->created_at);
            $date=date_format($time,'d-m-Y');
            $content=substr($e->content,0,500);
            ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><a href="<?php echo e(route('event.show',$e->id)); ?>"><?php echo e($e->name); ?></a></td>
                <td><?php echo e($date); ?></td>
                <td><?php echo e($e->place); ?></td>
                <td>
                <div class="btn-group">
                    <a href="<?php echo e(route('event.edit',$e->id)); ?>" class="btn btn-primary btn-sm mr-1">edit</a>
                    <form action="<?php echo e(route('event.destroy',$e->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">delete</button>
                    </form>
                </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">empty</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/event/index.blade.php ENDPATH**/ ?>