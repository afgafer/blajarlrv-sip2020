<?php $__env->startSection('content'); ?>
<div class="bg-limpid-light p-2">
            <div class="bg-light">
                <h1 class="title">form</h1>
                <div class="form-row p-2">
                    <div class="form-group col-md-6">
                        <label for="name">name</label>
                        <input type="text" value="<?php echo e(Session::get('name')); ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="hotel">hotel</label>
                        <input type="text" value="<?php echo e(Session::get('hotel')); ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="cin">cin : 08.00</label>
                        <input type="date"  value="<?php echo e(Session::get('cin')); ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group col-md-2">
                        <label for="cout">cout : 06.00</label>
                        <input type="date" value="<?php echo e(Session::get('cout')); ?>" class="form-control" readonly>
                    </div>
                </div>
            </div>
<h1 class="title text-center mt-2">hotels</h1>
<div class="card-columns">
            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            if(Session::has('cart')){
                $cart=Session::get('cart');
                if (array_key_exists($r->id,$cart->items)){
                    continue;
                }
            }
            $dirF='upload/img/'.$r->file;
            $src=asset($dirF);
            $price=number_format($r->price,0,',','.');
            //dd();
            ?>
            <div class="card p-0">
                <a class="text-dark" href="<?php echo e(route('order.room',$r->id)); ?>">
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($r->file); ?>">
                <div class="card-body">
                    <h5 class="card-title text-white badge badge-primary">No <?php echo e($r->id); ?></h5>
                    <h5 class="card-title border badge badge-light">Rp <?php echo e($r->price); ?></h5>
                    <table class="table table-sm bg-white mb-2 ">
                        <tbody>
                            <tr>
                                <td >Name</td>
                                <td>: <?php echo e($r->name); ?></td>
                            </tr>
                            <tr>
                                <td>bed</td>
                                <td>: <?php echo e($r->bed); ?></td>
                            </tr>
                            <tr>
                                <td>quota</td>
                                <td>: <?php echo e($r->quota); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/order/choice.blade.php ENDPATH**/ ?>