<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('cart.create')); ?>" method='post'>
    <?php echo e(csrf_field()); ?>

                <div class="form-row mx-2">
                    <div class="col-8 mb-4">
                        <label for="namaPemesan">namaPemesan</label>
                        <input type="text" class="form-control" name="namaPemesan" placeholder="namaPemesan"  value="<?php echo e(old('namaPemesan')); ?>" required>
                    </div>
                </div>
                <div class="form-row mx-2">
                    <div class="col-6 mb-4">
                        <label for="masuk">masuk</label>
                        <input type="date" class="form-control" name="masuk" placeholder="masuk" required>
                    </div>
                    <div class="col-6 mb-1">
                        <label for="keluar">keluar</label>
                        <input type="date" class="form-control" name="keluar" placeholder="keluar" required>
                    </div>
                </div>
                <button class="btn btn-primary" type="submit">Submit form</button>
            </form>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('lay.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/cart/search.blade.php ENDPATH**/ ?>