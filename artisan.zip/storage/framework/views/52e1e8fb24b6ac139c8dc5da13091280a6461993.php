<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('order.form')); ?>" class="btn btn-primary">order</a>
<div class="scroll">
        <table class="table table-sm bg-limpid-light">
            <thead>
                <tr class='bg-primary text-white'>
                    <th>No</th>
                    <th>name</th>
                    <th>cin</th>
                    <th>bill</th>
                    <th>status</th>
                    <th>action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            ?>

                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><a href="<?php echo e(route('order.showA',$o->id)); ?>"><?php echo e($o->name); ?></a></td>
                    <td><?php echo e($o->cin); ?></td>
                    <td><?php echo e($o->bill); ?></td>
                    <td><?php echo e($o->getStatus($o->status)); ?></td>
                    <td>
                    <?php if($o->status==3): ?>
                        <button class="btn btn-success" disabled>upload</button>
                    <?php else: ?>
                        <a href="<?php echo e(route('order.showA',$o->id)); ?>" class="btn btn-success">upload</a>
                    <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/order/index.blade.php ENDPATH**/ ?>