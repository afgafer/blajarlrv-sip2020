<?php $__env->startSection('content'); ?>
            <div class="card p-0 col-md-6">
            <?php
            $src='/upload/img/'.$room->file;
            ?>
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($room->image); ?>">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <table class="table table-sm bg-white mb-2">
                        <tbody>
                            <tr>
                                <td>Name</td>
                                <td>: <?php echo e($room->name); ?></td>
                            </tr>
                            <tr>
                                <td>price</td>
                                <td>: <?php echo e($room->price); ?></td>
                            </tr>
                            <tr>
                                <td>bed</td>
                                <td>: <?php echo e($room->bed); ?></td>
                                <td>quota</td>
                                <td>: <?php echo e($room->quota); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <h5 class="card-title">description :</h5>
                    <p><?php echo e($room->desc); ?></p>
                </div>
                <div class="card-footer">
                </div>
            </div>
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/room/show.blade.php ENDPATH**/ ?>