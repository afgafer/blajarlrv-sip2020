<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('message')): ?>
 <div class="alert alert-success martop-sm">
 <p><?php echo e($message); ?></p>
 </div>
<?php endif; ?>
<h1 class="text-center">users</h1>
<a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary btn-sm">create</a>
    <table class="table table-sm bg-white mb-2 ">
        <tbody>
            <tr class="bg-primary text-white">
                <th>no</th>
                <th>username</th>
                <th>email</th>
                <th>contact</th>
                <th>type</th>
                <th></th>
            </tr>
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $dirF='upload/img/'.$u->file;
            $src=asset($dirF);
            //$time=date_create($u->created_at);
            //$date=date_format($time,'d-m-Y');
            //$content=substr($u->content,0,500);
            if($u->type==1){
                $type='admin';
            }else{
                $type='user';
            }
            ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td>
                    <img src="<?php echo e($src); ?>" alt="<?php echo e($u->file); ?>" class="img-thumbnail">
                    <a href="<?php echo e(route('user.show',$u->id)); ?>"><?php echo e($u->name); ?></a>
                </td>
                <td><?php echo e($u->email); ?></td>
                <td><?php echo e($u->contact); ?></td>
                <td><?php echo e($type); ?></td>
                <td>
                    <a href="<?php echo e(route('user.edit',$u->id)); ?>" class="btn btn-primary btn-sm">edit</a>
                    <form action="<?php echo e(route('user.destroy',$u->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">empty</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/user/index.blade.php ENDPATH**/ ?>