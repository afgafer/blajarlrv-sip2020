<?php $__env->startSection('content'); ?>
            <div class="card p-0 col-md-6">
            <?php
            $dirF='/upload/img/'.$order->file;
            $src=asset($dirF);
            ?>
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <table class="table table-sm bg-white mb-2">
                        <tbody>
                            <tr>
                                <td>name</td>
                                <td>: <?php echo e($order->name); ?></td>
                            </tr>
                            <tr>
                                <td><img src="<?php echo e($src); ?>" alt="<?php echo e($order->file); ?>" class="img-thumbnail"></td>
                            </tr>
                            <form action="<?php echo e(route('order.upload',$order->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <!-- <tr>
                                <td colspan="3"><input type="file" name="file" id="file" class="form-control"></td>
                            </tr>-->
                            <tr>
                                <td>cin</td>
                                <td>: <?php echo e($order->cin); ?></td>
                            </tr>
                            <tr>
                                <td>cout</td>
                                <td>: <?php echo e($order->cout); ?></td>
                            </tr>
                            <tr>
                                <td>status</td>
                                <td>: <?php echo e($order->getStatus($order->status)); ?></td>
                            </tr>
                            </form>
                            <tr>
                                <td>bill</td>
                                <td>: <?php echo e($order->bill); ?></td>
                            </tr>
                            <tr>
                                <td>count</td>
                                <td>: <?php echo e($order->count); ?></td>
                            </tr>
                            <?php $__currentLoopData = $order->getORoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($r->id); ?></td>
                                <td>: <?php echo e($r->name); ?></td>
                                <td>: <?php echo e($r->qty); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <!-- <small class="text-muted row">
                        <form action="<?php echo e(route('order.cancel', $order->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <button class="btn btn-danger" type="submit">cancel</button>
                        </form>
                    </small> -->
                </div>
            </div>
    <!-- boodi -->
 <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/order/show.blade.php ENDPATH**/ ?>