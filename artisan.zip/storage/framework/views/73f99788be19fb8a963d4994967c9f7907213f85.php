<?php $__env->startSection('content'); ?>
            <div class="row p-2">
            <div class="card p-0 col-md-6">
            <?php
            if($user->type==1){
                $file=$user->admin->file;
            }else if($user->type==1){
                $file=$user->member->file;
            }
            $dirF='upload/img/'.$file;
            $src=asset($dirF);
            ?>
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($user->file); ?>">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <table class="table table-sm bg-white mb-2">
                        <tbody>
                            <tr>
                                <td>name</td>
                                <td>: <?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <td>email</td>
                                <td>: <?php echo e($user->email); ?> </td>
                            </tr>
                            <tr>
                                <td>contact</td>
                                <td>: <?php echo e($user->contact); ?></td>
                            </tr>
                            <?php if($user->type==1): ?>
                            <tr>
                                <td>hotel</td>
                                <td>: <?php echo e($user->admin->hotel->name); ?></td>
                            </tr>
                            <tr>
                                <td>dest</td>
                                <td>: <?php echo e($user->admin->dest->name); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    
                </div>
                <div class="card-footer">
                    <!-- <small class="text-muted"><a class="btn btn-primary" href="<?php echo e(route('dest.edit',$user->id)); ?>">edit</a></small> -->
                </div>
            </div>
            <div class="card p-0 col-md-6">
                <div class="card-body">
                    <table class="table table-sm mb-2">
                        <tbody>
                            <tr>
                                <td>transaction</td>
                                <td>
                                <?php
                                if(isset($transaction->count)){
                                    echo": ".$transaction->count;
                                }else{
                                    echo": 0";
                                }
                                ?>
                                </td>
                            </tr>
                            <tr>
                                <td>payment</td>
                                <td>
                                <?php
                                if(isset($payment->count)){
                                    echo": ".$payment->count;
                                }else{
                                    echo": 0";
                                }
                                ?>
                                </td>
                            </tr>
                            <tr>
                                <td>order</td>
                                <td>
                                <?php
                                if(isset($order->count)){
                                    echo": ".$order->count;
                                }else{
                                    echo": 0";
                                }
                                ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table table-sm bg-light mb-2">
                        <tbody>
                            <tr class="bg-primary text-white">
                                <th>id</th>
                                <th>room</th>
                                <th>slot</th>
                            </tr>
                            <?php $__empty_1 = true; $__currentLoopData = $user->admin->hotel->room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($r->id); ?></td>
                                <td><?php echo e($r->name); ?></td>
                                <td><?php echo e($r->slot); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3">empty</td>>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
 <?php $__env->stopSection(); ?>
 <?php $__env->startSection('script'); ?>
    <!-- <script crossorigin="anonymous" integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s=" src="https://code.jquery.com/jquery-3.1.0.min.js"></script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC6DzQ7KQPGFV7-F9mcF-Yy5SD4Dm1IiYI&libraries=places" type="text/javascript"></script>
    <script src="<?php echo e(asset('index.js')); ?>"></script> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/user/show.blade.php ENDPATH**/ ?>