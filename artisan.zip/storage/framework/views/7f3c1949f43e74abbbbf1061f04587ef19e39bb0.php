<?php $__env->startSection('content'); ?>
<h1 class="title">events</h1>
<div class="scroll">
    <table class="table table-sm bg-limpid-light mb-2">
        <tbody>
            <tr class="bg-primary text-white">
                <th>no</th>
                <th>name</th>
                <th>date</th>
                <th>place</th>
                <th></th>
            </tr>
            <?php
            //dd($events);
            ?>
            <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $dirF='upload/img/'.$e->file;
            $src=asset($dirF);
            $time=date_create($e->date);
            $date=date_format($time,'d/ m/ Y');
            $content=substr($e->content,0,500);
            ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><a href="<?php echo e(route('event.showA',$e->id)); ?>"><?php echo e($e->name); ?></a></td>
                <td><?php echo e($date); ?></td>
                <td><?php echo e($e->place); ?></td>
                <td>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="5" class="text-center">empty</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/event/index.blade.php ENDPATH**/ ?>