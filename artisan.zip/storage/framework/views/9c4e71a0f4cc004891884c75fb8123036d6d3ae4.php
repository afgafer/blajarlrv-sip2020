<?php $__env->startSection('header'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/18.0.0/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
$dirF='upload/img/'.$hotel->file;
$src=asset($dirF);
?>
            <form action="<?php echo e(route('hotel.update',$hotel->id)); ?>" method='post' enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo method_field('PUT'); ?>
                <div class="form-row mx-2">
                    <div class="col-md-6 mb-4">
                        <label for="name">name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e($hotel->name); ?>" required>
                    </div>
                </div>
                <div class="form-row mx-2">
                    <div class="col-md-6 mb-4">
                        <img src="<?php echo e($src); ?>" class="img-thumbnail" alt="<?php echo e($hotel->file); ?>">
                    </div>
                </div>
                <div class="form-row mx-2">
                    <div class="col-md-6 mb-4">
                        <input type="file" class="form-control" name="file" >
                    </div>
                </div>
                <div class="form-row mx-2">
                    <div class="col-md-6 mb-4">
                        <label for="contact">contact</label>
                        <input type="number" class="form-control" name="contact" value="<?php echo e($hotel->contact); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-12 mb-3">
                        <label for="address">address</label>
                        <textarea class="form-control" name="address"><?php echo e($hotel->address); ?></textarea>
                    </div>
                </div>
                <div class="form-row mx-2">
                    <div class="col-md-6 mb-4">
                        <label for="lat">lat</label>
                        <input type="number" class="form-control" name="lat" value="<?php echo e($hotel->lat); ?>">
                    </div>
                </div>
                <div class="form-row mx-2">
                    <div class="col-md-6 mb-4">
                        <label for="lng">lng</label>
                        <input type="number" class="form-control" name="lng" value="<?php echo e($hotel->lng); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-12 mb-3">
                        <label for="desc">desc</label>
                        <textarea class="form-control" id="editor" name="desc"><?php echo e($hotel->desc); ?></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-12 mb-3">
                        <button class="btn btn-primary" type="submit">save</button>
                        </div>
                </div>
            </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/hotel/edit.blade.php ENDPATH**/ ?>