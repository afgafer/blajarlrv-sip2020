<?php $__env->startSection('content'); ?>
        <div class="col-md-8 bg-white p-2">
            <form action="<?php echo e(route('user.update',$user->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('PUT')); ?>

                <div class="form-group">
                    <div class="col-md-5 mb-1">
                        <?php
                        $dirF='upload/img/'.$user->file;
                        $src=asset($dirF);
                        ?>
                        <img src="<?php echo e($src); ?>" class="img-thumbnail" alt="<?php echo e($user->file); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-5 mb-1">
                        <input type="file" class="form-control" name="file" >
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6 mb-4">
                        <label for="name">name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e($user->name); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6 mb-4">
                        <label for="email">email</label>
                        <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="contact">contact</label>
                    <input type="number" class="form-control" name="contact" value="<?php echo e($user->contact); ?>" required>
                </div>
                <button class="btn btn-primary" type="submit">save</button>
            </form>
        </div>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/user/edit.blade.php ENDPATH**/ ?>