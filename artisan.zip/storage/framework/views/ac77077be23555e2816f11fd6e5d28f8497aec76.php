<?php $__env->startSection('header'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/18.0.0/classic/ckeditor.js"></script>
<?php $__env->stopSection(); ?>

<?php
$dirF='upload/img/'.$article->file;
$src=asset($dirF);
?>

<?php $__env->startSection('content'); ?>
<div class="bg-white p-2">
<h1 class="title"><?php echo e($article->title); ?></h1>
<hr>
                <div class="form-row mx-2 ">
                    <div class="col-md-6 mb-4">
                        <img src="<?php echo e($src); ?>" alt="<?php echo e($article->file); ?>" class="img-thumbnail w-100 h-100">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-12 mb-3">
                        <label for="content">content</label>
                        <textarea class="form-control" id="editor" name="content"><?php echo e($article->content); ?></textarea>
                    </div>
                </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        ClassicEditor
            .create( document.querySelector( '#editor' ) )
            .catch( error => {
                console.error( error );
            } );
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/article/show.blade.php ENDPATH**/ ?>