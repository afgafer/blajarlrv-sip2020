<?php $__env->startSection('content'); ?>
<div class="bg-limpid-light p-2">
            <div class="bg-light">
                <h1 class="title">form</h1>
                <div class="form-row p-2">
                    <div class="form-group col-md-6">
                        <label for="name">name</label>
                        <input type="text" value="<?php echo e(Session::get('name')); ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="cin">cin : 08.00</label>
                        <input type="date"  value="<?php echo e(Session::get('cin')); ?>" class="form-control" readonly>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="cout">cout : 06.00</label>
                        <input type="date" value="<?php echo e(Session::get('cout')); ?>" class="form-control" readonly>
                    </div>
                </div>
            </div>
<h1 class="title text-center mt-2">hotels</h1>
<div class="card-columns">
            <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $dirF='upload/img/'.$h->file;
            $src=asset($dirF);
            ?>
            <div class="card p-0">
                <a class="text-dark" href="<?php echo e(route('order.choice',$h->id)); ?>">
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($h->file); ?>">
                <div class="card-body">
                    <h5 class="card-title text-white badge badge-primary">No <?php echo e($h->id); ?></h5>
                    <table class="table table-sm bg-white mb-2 ">
                        <tbody>
                            <tr>
                                <td >Name</td>
                                <td>: <?php echo e($h->name); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card p-0">
                <div class="card-body">
                    <h5>empty</h5>
                </div>
            </div>
            <?php endif; ?>
        </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/order/select.blade.php ENDPATH**/ ?>