<?php $__env->startSection('header'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-3 p-0 border border-dark">
            <?php if(isset($images)): ?>
            <div id="carouselExampleIndicators" style="height:300px; width:100%" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="4"></li>
                </ol>
                <div class="carousel-inner">
                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $dirF='upload/img/'.$i->file;;
                    $src=asset($dirF);
                    ?>
                    <?php if($loop->iteration==1): ?>
                    <div class="carousel-item active">
                        <img class="d-block" style="height:300px; width:100%" src="<?php echo e($src); ?>" alt="<?php echo e($i->name); ?>">
                        <div class="carousel-caption d-none d-md-block">
                            <p><?php echo e($i->desc); ?></p>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="carousel-item">
                        <img class="d-block" style="height:300px; width:100%" src="<?php echo e($src); ?>" alt="<?php echo e($i->name); ?>">
                        <div class="carousel-caption d-none d-md-block">
                            <p><?php echo e($i->desc); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
            <?php endif; ?>
        </div>
        <div class="col-lg-8 bg-dark text-white p-2">
            <?php if(isset($event)): ?>
            <?php
            $content=substr($event->desc,0,50);
            ?>
            <h1 ><?php echo e($event->name); ?></h1>
            <small><?php echo e($event->place); ?>,<?php echo e($event->date); ?></small>
            <p><?php echo e($content); ?></p>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel ea, nam, illum doloribus praesentium ex cum
                delectus totam deleniti non, laudantium maiores ad. Cupiditate eaque placeat sed quo ratione, quis minus
                quia voluptatem illum tempora iusto optio aut corporis inventore blanditiis exercitationem autem,
                distinctio, eveniet quae laudantium veniam quaerat esse necessitatibus. Dolorem aperiam nulla modi natus
                explicabo odio. Quia placeat odio quibusdam, explicabo laborum nemo praesentium animi libero tenetur amet
                ullam distinctio magnam aut laboriosam commodi, quo eaque eveniet obcaecati enim. Nulla ut temporibus
                explicabo dolorem suscipit quis perferendis debitis laboriosam blanditiis, similique iure laudantium tempore
                fugit at dignissimos hic.</p>
            <?php elseif(isset($dest)): ?>
            <?php
            $content=substr($dest->desc,0,50);
            ?>
            <h1 ><?php echo e($dest->name); ?></h1>
            <p><?php echo e($content); ?></p>
            <p class="">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel ea, nam, illum doloribus praesentium ex cum
                delectus totam deleniti non, laudantium maiores ad. Cupiditate eaque placeat sed quo ratione, quis minus
                quia voluptatem illum tempora iusto optio aut corporis inventore blanditiis exercitationem autem,
                distinctio, eveniet quae laudantium veniam quaerat esse necessitatibus. Dolorem aperiam nulla modi natus
                </p>
                <div>
                <button class="btn btn-primary btn-outline-light">read more</button>
                </div>
            <?php else: ?>
            <h1>empty</h1>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="">
    <!-- articles -->
    <h1 class="title">article list</h1>
    <hr>
    <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
    $dirF='upload/img/'.$a->file;
    $src=asset($dirF);
    $time=date_create($a->created_at);
    $date=date_format($time,'d/m/Y');
    $content=substr($a->content,0,300);
    $mod=$loop->iteration%2;
    ?>
    <?php if($mod): ?>
    <div class="card mb-3 p-1"> 
        <div class="row no-gutters">
            <div class="col-md-3 align-self-center">
                <img src="<?php echo e($src); ?>" class="card-img" alt="<?php echo e($a->file); ?>">
            </div>
            <div class="col-md-8 ">
                <div class="card-body">
                    <h4 class="card-title text-primary"><?php echo e($a->title); ?></h4>
                    <p class="card-text"><?php echo e($content); ?></p>
                    <p class="card-text"><span
                                class="badge badge-primary"><?php echo e($a->admin->name); ?></span><span
                                class="badge badge-secondary"><?php echo e($date); ?></span></p>
                </div>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="card mb-3 p-1">
        <div class="row no-gutters">
             <div class="col-md-8">
                <div class="card-body">
                    <h4 class="card-title text-primary"><?php echo e($a->title); ?></h4>
                    <p class="card-text"><?php echo e($content); ?></p>
                    <p class="card-text"><span
                                class="badge badge-primary"><?php echo e($a->admin->name); ?></span><span
                                class="badge badge-secondary"><?php echo e($date); ?></span></p>
                </div>
            </div>
            <div class="col-md-3 align-self-center ml-auto">
                <img src="<?php echo e($src); ?>" class="card-img" alt="<?php echo e($a->file); ?>">
            </div>
            
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h5>empty</h5>
    <?php endif; ?>
    <!-- articles end-->
</div>
<div class="bg-white p-2">
    <!-- rooms -->
    <h1 class="title">room list</h1>
    <hr>
    <?php if(isset($rooms)): ?>
    <div class="row row-cols-1 row-cols-md-4">
        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $dirF='upload/img/'.$r->file;
        $src=asset($dirF);
        $price=number_format($r->price,0,'','.');
        ?>
        <div class="col mb-4">
            <div class="card h-100 border border-white">
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($r->file); ?>">
                <div class="card-body">
                    <h5 class="card-title text-white badge badge-primary">No <?php echo e($r->id); ?></h5>
                    <h5 class="card-title border badge badge-light">Rp <?php echo e($price); ?></h5>
                    <table class="table table-sm bg-white mb-2 ">
                        <tbody>
                            <tr>
                                <td>Name</td>
                                <td>: <?php echo e($r->name); ?></td>
                            </tr>
                            <tr>
                                <td>hotel</td>
                                <td>: <?php echo e($r->hotel->name); ?></td>
                            </tr>
                            <tr>
                                <td>bed</td>
                                <td>: <?php echo e($r->bed); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php else: ?>
    <h5>empty</h5>
    <?php endif; ?>
    <!-- rooms end-->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/welcome.blade.php ENDPATH**/ ?>