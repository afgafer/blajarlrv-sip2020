<?php $__env->startSection('content'); ?>

<?php if($message = Session::get('message')): ?>
 <div class="alert alert-success martop-sm">
 <p><?php echo e($message); ?></p>
 </div>
<?php endif; ?>
<h1 class="title">articles</h1>
<div class="card-columns">
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
            $dirF='upload/img/'.$a->file;
            $src=asset($dirF);
            $time=date_create($a->created_at);
            $date=date_format($time,'d/m/Y');
            $content=substr($a->content,0,500);
            ?>
            <div class="card p-0">
                <a class="text-dark" href="<?php echo e(route('article.showA',$a->id)); ?>">
                <img src="<?php echo e($src); ?>" class="card-img-top" alt="<?php echo e($a->file); ?>">
                <div class="card-body">
                    <table class="table table-sm bg-white mb-2 ">
                        <tbody>
                            <tr>
                                <td >title</td>
                                <td>: <?php echo e($a->title); ?></td>
                            </tr>
                            <tr>
                                <td>writer</td>
                                <td>: <?php echo e($a->admin->name); ?></td>
                            </tr>
                            <tr>
                                <td>date</td>
                                <td>: <?php echo e($date); ?></td>
                            </tr>
                        </tbody>
                    </table>
                    <?=$content?>
                    <div>
                        <a href="<?php echo e(route('article.showA',$a->id)); ?>" class="btn btn-outline-primary btn-sm">read more >></a>
                    </div>
                </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="card p-0">
                <div class="card-body">
                    <h5>empty</h5>
                </div>
            </div>
            <?php endif; ?>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/article/index.blade.php ENDPATH**/ ?>