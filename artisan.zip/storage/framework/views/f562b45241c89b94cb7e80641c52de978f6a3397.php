<?php $__env->startSection('content'); ?>
            <form action="<?php echo e(route('image.update',$image->id)); ?>" method='post' enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <?php echo e(method_field('put')); ?>

                <div class="form-group">
                    <div class="col-md-6">
                        <label for="name">name</label>
                        <input type="text" class="form-control" name="name" value="<?php echo e($image->name); ?>" >
                    </div>
                </div>
                <?php
            $dirF='upload/img/'.$image->file;
            $src=asset($dirF);
            ?>
                <div class="form-group">
                    <div class="col-md-6">
                        <img src="<?php echo e($src); ?>" class="img-thumbnail" width="100px" heigth="100px" alt="<?php echo e($image->file); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6">
                        <input type="file" class="form-control" name="file" >
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-4">
                        <label for="dest">dest</label>
                        <select name="dest" class="form-control">
                            <option disabled selected>--Pilih--</option>
                            <?php
                            $dests=\App\models\Dest::orderBy('name','ASC')->get();
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $dests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <option <?php echo e($d->id==$image->dest_id? 'selected="selected"' : ''); ?> value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <option disabled selected>empty</option>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-12">
                        <label for="desc">Deskripsi</label>
                        <textarea class="form-control" required="" name="desc"><?php echo e($image->desc); ?></textarea>
                    </div>
                </div>
                <button class="btn btn-primary" type="submit">Submit form</button>
            </form>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/image/edit.blade.php ENDPATH**/ ?>