<?php $__env->startSection('content'); ?>
<?php
if(isset($_GET['date1']) and isset($_GET['date2'])){
    $date1=$_GET['date1'];
    $date2=$_GET['date2'];
}else{
    $date1=date('Y-m-d');
    $date2=date('Y-m-d', strtotime("+1 days", strtotime($date1)));
}
?>
<div class="bg-light">
    <h1 class="title">form</h1>
    <div class="form-row p-2">
        <div class="form-group col-md-2">
            <label for="cin">cin : 08.00</label>
            <input type="date"  value="<?php echo e($date1); ?>" id="date1" class="form-control">
        </div>
        <div class="form-group col-md-2">
            <label for="cout">cout : 06.00</label>
            <input type="date" value="<?php echo e($date2); ?>" id="date2" class="form-control">
        </div>
        <div class="form-group col-md-2">
            <button class="btn btn-primary" id="filter">filter</button>
        </div>
    </div>
    <div class="form-group col-md-4 ">
            <input type="text" placeholder="name room" id="search" class="form-control">
    </div>
</div>
<h1 class="title text-center mt-2">hotels</h1>
<div class="card-columns" id="result">
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
    
    $(document).ready(function() {
        fetch();
            $(document).on('click','#filter',function(){
                fetch();
            });
        function fetch(query='') {
            query=$('#search').val();
            date1=$('#date1').val();
            date2=$('#date2').val();
            $.ajax({
                url:"http://localhost:8000/room/search",
                method:'GET',
                data:{query:query,date1:date1,date2:date2},
                dataType:'json',
                success: function(data){
                    $('#result').html(data.card_data);
                }
            });
        }
        $(document).on('keyup','#search',function(){
           var query=$(this).val();
           fetch(query);
        });
       
    });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Auth\resources\views/auth/room/check.blade.php ENDPATH**/ ?>